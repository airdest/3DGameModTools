Copyright © LWChris 2022

http://forums.getpaint.net/index.php?/topic/110805-modify-channels

* The plugin is free to use for anything permitted by applicable law (including commercial purposes).
* You are however not allowed to modify or sell this plugin.
* Do not redistribute the plugin except by sharing links to the Paint.NET forum post please. If you want to include it in your plugin pack, please ask for my permission over there first.
* The plugin is provided "as is", without warranty of any kind, express or implied, including but not limited to the warranties of merchantability, fitness for a particular purpose and noninfringement. In no event shall I or copyright holders be liable for any claim, damages or other liability, whether in an action of contract, tort or otherwise, arising from, out of or in connection with the plugin or the use or other dealings in the plugin.